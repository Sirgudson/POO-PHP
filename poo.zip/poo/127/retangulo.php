<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Calcula Retângulo</title>
</head>
<body>
   <h2>Retângulo</h2>
   <form action="127.php" method="post">
    Informe a largura:<input type="number" name="largura" id="largura" step="0.01"><br>
    Informe a altura:<input type="number" name="altura" id="altura" step="0.01"><br>
    <input type="submit" value="Calcula Área">
   </form>

</body>
</html>